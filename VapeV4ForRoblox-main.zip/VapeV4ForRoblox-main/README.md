
# Vape V4
**When you make a script for 3 years, and blow up on a ripoff lego game**
_Project I made becasue I want to expand my creativity_ Made By 7GrandDadPGN | removed the entity by: ntd / stable version by shuttle
